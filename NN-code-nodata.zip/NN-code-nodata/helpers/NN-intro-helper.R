## Using "BreastCancer" dataset from mlbench R-library
data(BreastCancer)

## Processing the BreastCancer dataset a bit
BreastCancer <- BreastCancer %>% na.omit()

y = as.matrix(ifelse(BreastCancer$Class == "benign", 0, 1), ncol = 1)
X = data.matrix(BreastCancer %>% select(-Id, -Class))

## A function which will create a data object that can be used by torch (the NN library)
### In general when formatting data for torch you will need something like this
BreastCancer_dataset <- dataset(
  name = "BreastCancer",
  initialize = function(x,y){
    self$x = torch_tensor(x, dtype = torch_float32())
    self$y = torch_tensor(y, dtype = torch_float32())
  },
  
  ## boilerplate stuff
  .getitem = function(i){
    list(x = self$x[i,], y = self$y[i])
  },
  
  ## more boilerplate stuff
  .length = function(){
    self$y$size()[[1]]
  }
)

## Creating our training/validation data (and moving them into torch-format)
ind.train <- sample(1:length(y), length(y)/2, replace = F) ## using half our data for training
train_ds <- BreastCancer_dataset(X[ind.train,], y[ind.train])
valid_ds <- BreastCancer_dataset(X[-ind.train,], y[-ind.train])

## Creating a "dataloader" that allows torch to do calculations with the data
train_dl <- train_ds %>% dataloader(batch_size = 16, shuffle = TRUE)
valid_dl <- valid_ds %>% dataloader(batch_size = 16, shuffle = FALSE)


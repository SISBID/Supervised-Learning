
# Function to plot an out of sample ROC curve
make.roc <- function(PREDS, outcomes, ...){
  prediction.obj <- prediction(PREDS, outcomes)

  roc.obj <- performance(prediction.obj, "tpr", "fpr")
  auc.obj <- performance(prediction.obj, measure = "auc")

  auc <- auc.obj@y.values[[1]]

  plot(roc.obj, font.main=1, ...)
  text(x=0.6, y=0.1, paste0("AUC: ", round(auc, 2)))
  abline(a=0, b=1, lty=2)
}

# Function to get mis-classification error
# Rounds probability predictions up if > 0.5
get.misclass.error <- function(preds, outcomes){
  mean(round(preds) != outcomes)
}

# Function to create a calibration plot
calibrate <- function(preds, outcomes, ...){
  # Use a degree 3 spline, higher degree sometimes breaks
  calibrate.plot(outcomes, preds,
                 main="Calibration Plot", font.main=1,
                 df=3)
}

make.plots <- function(preds, outcomes, ...){
  par(mfrow=c(1, 2))
  make.roc(preds, outcomes, ...)
  calibrate(preds, outcomes)
}

### Function to identify where the internal and boundary knots are for natural splines
build.spline.info <- function(dat.to.use, vars.to.use, num.knots){
  quantiles <- seq(from = 0, to = 1, length.out = num.knots + 2)[-c(1,num.knots+2)]
  spline.info <- list()
  for(var.name in vars.to.use){
    spline.info[[var.name]] <- list()
    knots.all <- quantile(dat.to.use[[var.name]], quantiles)
    spline.info[[var.name]]$k <- knots.all[-c(1,num.knots)]
    spline.info[[var.name]]$bk <- range(knots.all)
  }
  return(spline.info)
}

# Function to plot marginal effect of polynomial/spline variables
### This is written specifically for the infarcts data 
### (some things are hardcoded in)
plot.spline <- function(fit, col, knots=NULL){
  cols <- colnames(dat)[!colnames(dat) %in% c(col, "infarcts",
                                              "chd", "claud", "htn", "diabetes")]

  xmat <- dat[, lapply(.SD, mean), .SDcols=cols]

  xmat[, chd := factor(0)]
  xmat[, claud := factor(0)]
  xmat[, htn := factor(0)]
  xmat[, diabetes := factor(0)]

  var_seq <- seq(min(dat[[col]]), max(dat[[col]]), by=0.1)

  xmat <- replicate(length(var_seq), xmat, simplify = F) %>% rbindlist
  xmat <- cbind(xmat, var_seq)
  setnames(xmat, "var_seq", col)

  preds.marg <- predict(fit, newdata=xmat, type="response")
  plot(preds.marg ~ var_seq, main=paste0("Marginal effect of ", col),
       xlab=col, ylab="Probability", type='l')

  if(!is.null(knots)){
    abline(v=knots, lty=3)
  }
}

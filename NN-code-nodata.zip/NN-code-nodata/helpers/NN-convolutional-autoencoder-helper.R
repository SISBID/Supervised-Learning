####### MNIST DATA

## This allows us to switch between running things on a CPU and GPU
### you will see throughout the code that we indicate the "device =" argument in a number of functions
### to swap to gpu change "cpu" to "cuda"
### However! You need your torch installation to be set up to use a gpu
### it turns out that is a bit more involved (so more work may be needed!)
device <- torch_device("cpu")

#mnist.train <- read.csv("data/mnist/mnist_train.csv")
#mnist.test <- read.csv("data/mnist/mnist_test.csv")

## Here we split off the pieces of training and validation data
### We also reshape our image-dataset into a 4-dimensional tensor
### the first dimension indexes the images
### the second dimension indexes the "color-channel" (in our case we only have 1 color)
### the next two dimensions index the x and y positions on the image
### the value at each element in the array is a grey-scale intensity

y.train <- mnist.train[,1]+1
X.train <- data.matrix(mnist.train[,-1])/255
X.train.array <- array(X.train, dim = c(nrow(X.train),1,28,28))

y.test <- mnist.test[,1]+1
X.test <- data.matrix(mnist.test[,-1])/255
X.test.array <- array(X.test, dim = c(nrow(X.test),1,28,28))

## A function which will create a data object that can be used by torch (the NN library)
### In general when formatting data for torch you will need something like this
mnist_dataset <- dataset(
  name = "mnist",
  initialize = function(x){
    self$x = torch_tensor(x, dtype = torch_float32(), device = device)
   },
  
  ## boilerplate stuff
  .getitem = function(i){
    list(x = self$x[i,], y = self$x[i,])
  },
  
  ## more boilerplate stuff
  .length = function(){
    self$x$size()[[1]]
  }
)

## moving our training and validation datasets into "torch-format"

train_ds <- mnist_dataset(X.train.array)
valid_ds <- mnist_dataset(X.test.array)

## Creating a "dataloader" that allows torch to do calculations with the data
train_dl <- train_ds %>% dataloader(batch_size = 512, shuffle = TRUE)
valid_dl <- valid_ds %>% dataloader(batch_size = 512, shuffle = FALSE)


## A simple helper functions to allow us to visualize the images of the digits
plot_digit <- function(image_vec, dims = c(28,28)){
  image_mat <- matrix(image_vec, ncol = dims[2])
  image_mat <- image_mat[,ncol(image_mat):1]
  image(image_mat, axes = FALSE, col = grey(seq(0, 1, length = 256)))
}

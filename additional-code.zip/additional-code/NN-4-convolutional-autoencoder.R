library(luz)
library(torch)
library(dplyr)


## We first read in the mnist data:
### This dataset contains 28x28 greyscale images of handwritten digits (between 0 and 9)
### In addition, we have a numeric label of the handwritten digit for each image

mnist.train <- read.csv("data/mnist/mnist_train.csv")
mnist.test <- read.csv("data/mnist/mnist_test.csv")

dim(mnist.train)
dim(mnist.test)

## This will format our data into the formed needed to engage with the neural network
### in practice you will have to do this on your own...
### for now I wanted to focus on the NN piece, not the formatting

source("helpers/NN-convolutional-autoencoder-helper.R")

## After running this there will be a few objects created that we will use later:
### train_ds -- the training data in torch-format
### valid_ds -- the validation data in torch-format
### train_dl -- a training dataloader 
######          that includes our training dataset, and some additional info
### valid_dl -- a validation dataloader 
######          that includes our validation dataset, and some additional info

## Here we define the neural network infrastructure/topology
### The code is a bit unusual compared to how we usually fit models in R
conv_autoencoder <- nn_module(
  
  ## This tells us how to build all the trainable layers
  initialize = function() {
    n_dim = 2
    self$encoder <- nn_sequential(
      nn_conv2d(in_channels = 1, out_channels = 32, kernel_size = 3, padding = 1),
      nn_relu(),
      nn_max_pool2d(c(2.2), stride = 2),
      
      nn_conv2d(in_channels = 32, out_channels = 64, kernel_size = 3, padding = 1),
      nn_relu(),
      nn_max_pool2d(c(2.2), stride = 2),
      
      nn_flatten(start_dim = 2),
      
      nn_linear(in_features = 64*7*7, out_features = 32),
      nn_relu(),
      nn_linear(in_features = 32, out_features = n_dim)
    )
    self$decoder <- nn_sequential(
      nn_linear(in_features = n_dim, out_features = 32),
      nn_relu(),
      nn_linear(in_features = 32, out_features = 28*28),
      nn_relu(),
      nn_unflatten(2, c(1, 28, 28)),
      nn_conv_transpose2d(in_channels = 1, out_channels = 32, kernel_size = 3, padding = 1),
      nn_relu(),
      nn_conv_transpose2d(in_channels = 32, out_channels = 64, kernel_size = 3, padding = 1),
      nn_conv2d(in_channels = 64, out_channels = 1, kernel_size = 1),
      nn_sigmoid()
    )
      
  },
  
  ## This tells us how to order/connect the layers for training
  forward = function(x) {
    
    x %>% 
      self$encoder() %>%
      self$decoder()
  },
  ## This allows us to grab out the embeddings after training
  run_encoder = function(x) {
    x %>% self$encoder()
  }

)

## Here we just check to make sure we have defined our NN correctly...
### such that the dimensions of the inputs and outputs line up correctly
model_autoencoder <- conv_autoencoder()
batch <- dataloader_make_iter(train_dl) %>% dataloader_next() ## You generally won't have to worry about the functions here
model_autoencoder(batch$x)
model_autoencoder$run_encoder(batch$x)

## This is the code that takes our NN, and...
#### constructs/trains it based on our training data
#### and evaluates the results based on validation data
fitted <- conv_autoencoder %>%
  setup(
    loss = nn_mse_loss(),
    optimizer = optim_adam
  ) %>%
  set_opt_hparams(lr = 0.001) %>%
  fit(train_dl, epochs = 3, valid_data = valid_dl)

## This gives us predictions on the validation data
(preds <- predict(fitted, valid_ds))
## can also get these using the following syntax
fitted$model(valid_ds$x)

## Can compare original values to embedded values
index_use <- 4 ## the index of the observation I want to compare
cbind(preds[index_use,] %>% as.numeric(),
      train_ds[index_use]$x %>% as.numeric())
plot_digit(preds[index_use,] %>% as.numeric())
plot_digit(valid_ds[index_use]$x %>% as.numeric())


## can get the embeddings/encodings of the eg. validation data with
(encodings <- fitted$model$run_encoder(valid_ds$x))

plot(encodings[,1],encodings[,2], col = y.test)

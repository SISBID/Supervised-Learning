library(data.table)
library(rpart)
library(rpart.plot)
library(ranger)
library(gbm)
library(ROCR)
library(dplyr)
library(glmnet)
library(splines)
library(missRanger)

source("helpers/utils.R")


## This should be the path from your working directory to your data
## Often your working directory is where your script lives
path_to_data <- "data/infarcts-data/"

# DATA READING AND CLEANING ------------------------
dat.unclean <- read.table(paste0(path_to_data, "infarcts.txt"), header=T) %>% data.table

# Select variables to use
dat.unclean <- dat.unclean[, .(infarcts, age, educ, income, weight, height,
               packyrs, alcoh, chd, claud, htn, diabetes, ldl, crt)]
dat.unclean[, chd := as.factor(chd)]
dat.unclean[, claud := as.factor(claud)]
dat.unclean[, htn := as.factor(htn)]
dat.unclean[, diabetes := as.factor(diabetes)]

# set a seed to analysis reproducible
set.seed(10)

## Two methods for dealing with missing data

## Can impute 
#### (here we impute once at the beginning, but could do this separately in training/test)
dat <- missRanger(dat.unclean, .-infarcts ~ . - infarcts, pmm.k = 3, num.trees = 100)

# Or could just remove rows with missing features
#dat <- na.omit(dat.unclean)

# Split data into training and testing
train.ind <- sample(1:nrow(dat), floor(nrow(dat)/2))
dat.train <- dat[train.ind,]
dat.test <- dat[-train.ind,]

# MODEL FITTING ------------------------------------


# (0) LOGISTIC REGRESSION
# -----------------------
fit.lr <- glm(infarcts ~ ., data=dat.train,
              family=binomial(link="logit"))
pred.lr <- predict(fit.lr, newdata=dat.test, type="response")

make.plots(pred.lr, dat.test$infarcts, main="Logistic Regression")
get.misclass.error(pred.lr, dat.test$infarcts)

# (1) FEATURE ENGINEERING
# --------------------------

# (a) POLYNOMIALS ----------

# Specify some continuous variables as a polynomial rather than
# a single linear term
poly.deg <- 3

fit.poly <- glm(infarcts ~ .-(age)-(height)-(weight) +
                          poly(age, poly.deg) + poly(height, poly.deg) + poly(weight,poly.deg),
                data=dat.train,
                family=binomial(link="logit"))
pred.poly <- predict(fit.poly, newdata=dat.test, type="response")

# Plot the marginal relationship between predictor and outcome
plot.spline(fit.poly, "age")
plot.spline(fit.poly, "height")
plot.spline(fit.poly, "weight")

make.plots(pred.poly, dat.test$infarcts, main="Logistic Regression")
get.misclass.error(pred.poly, dat.test$infarcts)

# (b) SPLINES --------------

# Identify knots for splines
num.knots <- 3
vars.to.use <- c("age","height", "weight")
info <- build.spline.info(dat.train, vars.to.use, num.knots)

# Fit logistic regression with spline parameterizations, degree 3,
# with the knots specified above, for age, height, and weight
fit.spline <- glm(infarcts ~ .-(age)-(height)-(weight) +
                          ns(age, knots=info[["age"]]$k, Boundary.knots = info[["age"]]$bk) +
                          ns(height, knots=info[["height"]]$k, Boundary.knots = info[["height"]]$bk) +
                          ns(weight, knots=info[["weight"]]$k, Boundary.knots = info[["weight"]]$bk),
                  data=dat.train,
                  family=binomial(link="logit"))

pred.spline <- predict(fit.spline, newdata=dat.test, type="response")

# Plot the marginal relationship between predictor and outcome
plot.spline(fit.spline, "age", knots=info[["age"]]$k)
plot.spline(fit.spline, "height", knots=info[["height"]]$k)
plot.spline(fit.spline, "weight", knots=info[["weight"]]$k)

make.plots(pred.spline,dat.test$infarcts, main="Logistic Regression")
get.misclass.error(pred.spline, dat.test$infarcts)

# (2) RANDOM FOREST
# --------------------------
fit.ranger <- ranger(as.factor(infarcts) ~ .,
                     data = dat.train,
                     mtry = 5,
                     probability = TRUE)

preds.ranger <- predict(fit.ranger, dat.test)$predictions[, 2]

make.plots(preds.ranger, dat.test$infarcts, main="Random Forest")

get.misclass.error(preds.ranger, dat.test$infarcts)

# (3) LASSO
# ---------

# Create covariates matrix (without intercept) and outcome vector
x.train <- model.matrix(infarcts ~ 0 + ., data=dat.train)
x.test <- model.matrix(infarcts ~ 0 + ., data=dat.test)

y.train <- dat.train$infarcts
y.test <- dat.test$infarcts

# Fit a lasso model (alpha = 1 [alpha = 0 corresponds to ridge regression])
fit.lasso <- glmnet(x=x.train, y=y.train,
                    family="binomial", alpha=1)

# Create a coefficient plot
plot(fit.lasso)

# Perform cross-validation to see what the best lambda was
# and plot mean squared error
cv.lasso <- cv.glmnet(x=x.train, y=as.numeric(y.train),
                      alpha=1, nfolds=10, type.measure="deviance")
plot(cv.lasso)

# Get the best lambda, and see the values for the coefficients
# plus which ones were dropped out of the model (denoted with ".")
lambda.min <- cv.lasso$lambda.min
predict(fit.lasso, type="coefficients", s=lambda.min)

# Compare to a larger lambda within 1 SE,
# this is a sparser model
lambda.1se <- cv.lasso$lambda.1se
predict(fit.lasso, type="coefficients", s=lambda.1se)

# Get predictions with both of the lambda values
preds.lasso.best <- predict(fit.lasso, newx=x.test, type="response", s=lambda.min)
preds.lasso.1se <- predict(fit.lasso, newx=x.test, type="response", s=lambda.1se)

make.plots(preds.lasso.best, dat.test$infarcts, main="Best Lambda")
make.plots(preds.lasso.1se, dat.test$infarcts, main="Sparser Model")

get.misclass.error(preds.lasso.best, dat.test$infarcts)
get.misclass.error(preds.lasso.1se, dat.test$infarcts)

# (4) BOOSTING
# ------------

fit.gbm.2 <- gbm(infarcts ~ .,
                 data = dat.train,
                 distribution = "bernoulli",
                 n.trees = 1000,
                 interaction.depth = 2,
                 shrinkage = 0.01,
                 cv.folds = 4,
                 bag.fraction = 0.2)

fit.gbm.3 <- gbm(infarcts ~ .,
                 data = dat.train,
                 distribution = "bernoulli",
                 n.trees = 1000,
                 interaction.depth = 3,
                 shrinkage = 0.01,
                 cv.folds = 4,
                 bag.fraction = 0.2)

best.fit.gbm.2 <- gbm.perf(fit.gbm.2, method="cv")
best.fit.gbm.3 <- gbm.perf(fit.gbm.3, method="cv")

preds.gbm.2 <- predict(fit.gbm.2, dat.test,
                       ntree=best.fit.gbm.2, type="response")
preds.gbm.3 <- predict(fit.gbm.3, dat.test,
                       ntree=best.fit.gbm.3, type="response")

make.plots(preds.gbm.2, dat.test$infarcts, main="Boosting, Interaction Depth: 2")
make.plots(preds.gbm.3, dat.test$infarcts, main="Boosting, Interaction Depth: 3")

get.misclass.error(preds.gbm.2, dat.test$infarcts)
get.misclass.error(preds.gbm.3, dat.test$infarcts)


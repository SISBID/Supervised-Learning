library(data.table)
library(rpart)
library(rpart.plot)
library(ranger)
library(missRanger)
library(gbm)
library(ROCR)
library(dplyr)

source("helpers/utils.R")

# set a reproducible seed
set.seed(10)

# USER CHOICES -------------------------------------

# Set which outcome you're interested in
# pick one of "seasonal_vaccine" or "h1n1_vaccine"
outcome <- "seasonal_vaccine"

# DATA READING AND CLEANING ------------------------

## This should be the path from your working directory to your data
## Often your working directory is where your script lives
path_to_data <- "data/flu-data/"

features <- fread(paste0(path_to_data,"training_set_features.csv"))
labels <- fread(paste0(path_to_data,"training_set_labels.csv"))

dat.unclean <- merge(features, labels, by="respondent_id")

# Delete columns that shouldn't be used as predictors
dat.unclean[, hhs_geo_region := NULL]
dat.unclean[, employment_industry := NULL]
dat.unclean[, employment_occupation := NULL]
dat.unclean[, respondent_id := NULL]

# Create outcome variable and delete the other one
# so we don't accidentally use it
dat.unclean[, outcome := get(outcome)]
dat.unclean[, seasonal_vaccine := NULL]
dat.unclean[, h1n1_vaccine := NULL]

# Re-code variables as factors
dat.unclean[, age_group := as.factor(age_group)]
dat.unclean[, education := as.factor(education)]
dat.unclean[, race := as.factor(race)]
dat.unclean[, sex := as.factor(sex)]
dat.unclean[, income_poverty := as.factor(income_poverty)]
dat.unclean[, marital_status := as.factor(marital_status)]
dat.unclean[, rent_or_own := as.factor(rent_or_own)]
dat.unclean[, employment_status := as.factor(employment_status)]
dat.unclean[, census_msa := as.factor(census_msa)]

## Two methods for dealing with missing data

## Can impute 
#### (here we impute once at the beginning, but could do this separately in training/test)
dat <- missRanger(dat.unclean, .-outcome ~ . -outcome, pmm.k = 3, num.trees = 25)

# Or could just remove rows with missing features
dat <- na.omit(dat.unclean)

# Split data into training and testing
train.ind <- sample(1:nrow(dat), floor(nrow(dat)/2))
dat.train <- dat[train.ind,]
dat.test <- dat[-train.ind,]

# MODEL FITTING ------------------------------------

# (0) LOGISTIC REGRESSION
# -----------------------
fit.lr <- glm(outcome ~ ., data=dat.train,
              family=binomial(link="logit"))
pred.lr <- predict(fit.lr, newdata=dat.test, type="response")

make.plots(pred.lr, dat.test$outcome, main="Logistic Regression")
get.misclass.error(pred.lr, dat.test$outcome)

# (1) SINGLE REGRESSION TREE
# --------------------------
fit <- rpart(formula = as.factor(outcome) ~ .,
             data = dat.train,
             control = rpart.control(cp = 0.0002))
cpTab <- printcp(fit)
plotcp(fit)

# Get the tree with the minimum error
minErr <- which.min(cpTab[,4])
tree.best <- prune(fit, cp = cpTab[minErr,1])
rpart.plot(tree.best)

# Get a "good" tree w/ minimal complexity (within 1 standard error)
good_inds <- which(cpTab[,4]<cpTab[minErr,4]+1*cpTab[minErr,5])
min_complexity_ind <- good_inds[1]
tree.1se <- prune(fit, cp = cpTab[min_complexity_ind,1])
rpart.plot(tree.1se)

# Make predictions for the test set based on "best" tree
# and minimal complexity, out of sample.
# (extracting the second column b/c it's the probability of being a 1)
preds.1se <- predict(tree.1se, dat.test)[, 2]
preds.best <- predict(tree.best, dat.test)[, 2]

make.plots(preds.1se,dat.test$outcome, main="Min. Complexity Tree")
make.plots(preds.best,dat.test$outcome, main="Best Tree")

# (2) RANDOM FOREST
# --------------------------
fit.ranger <- ranger(as.factor(outcome) ~ .,
                     data = dat.train,
                     mtry = 5,
                     probability = TRUE)

preds.ranger <- predict(fit.ranger, dat.test)$predictions[, 2]

par(mfrow=c(1, 2))
make.plots(preds.ranger,dat.test$outcome, main="Random Forest")

# (3) BOOSTING
# ------------

fit.gbm.1 <- gbm(outcome ~ .,
                 data = dat.train,
                 distribution = "bernoulli",
                 n.trees = 1000,
                 interaction.depth = 1,
                 shrinkage = 0.1,
                 cv.folds = 4,
                 bag.fraction = 0.1)

fit.gbm.2 <- gbm(outcome ~ .,
                 data = dat.train,
                 distribution = "bernoulli",
                 n.trees = 1000,
                 interaction.depth = 2,
                 shrinkage = 0.1,
                 cv.folds = 4,
                 bag.fraction = 0.1)

best.fit.gbm.1 <- gbm.perf(fit.gbm.1, method="cv")
best.fit.gbm.2 <- gbm.perf(fit.gbm.2, method="cv")

preds.gbm.1 <- predict(fit.gbm.1, dat.test,
                       ntree=best.fit.gbm.1, type="response")
preds.gbm.2 <- predict(fit.gbm.2, dat.test,
                       ntree=best.fit.gbm.2, type="response")

make.plots(preds.gbm.1,dat.test$outcome, main="Boosting, Interaction Depth: 1")
make.plots(preds.gbm.2,dat.test$outcome, main="Boosting, Interaction Depth: 2")

get.misclass.error(preds.gbm.1,dat.test$outcome)
get.misclass.error(preds.gbm.2,dat.test$outcome)


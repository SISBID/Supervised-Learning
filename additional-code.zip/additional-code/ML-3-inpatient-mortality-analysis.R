### Dataset can be found here: https://datadryad.org/stash/dataset/doi:10.5061/dryad.0p2ngf1zd

## These libraries aren't necessary, but might be useful!

library(dplyr)
library(ROCR)
library(gbm)
library(ranger)
library(missRanger)
library(glmnet)

## This should be the path from your working directory to your data
## Often your working directory is where your script lives
path_to_data <- "data/inpatient-mortality-data/"

dat <- read.csv(paste0(path_to_data,"mortality-data.csv"))

## If the data is in your working directory, can instead use
# dat <- read.csv("mortality-data.csv")


### Some steps to consider

## Break into training/test set (remember to set a seed!)

## Impute (without using outcome)

## Fit some models on the training set
#### (eg. penalized regression, random forests, boosting)

## Perhaps try engineering some features

## Evaluate the models on the test set
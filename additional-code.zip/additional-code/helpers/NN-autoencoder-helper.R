## Using "BreastCancer" dataset from mlbench R-library
data(BreastCancer)

## Processing the BreastCancer dataset a bit
BreastCancer <- BreastCancer %>% na.omit()

X = data.matrix(BreastCancer %>% select(-Id, -Class))
y = as.matrix(ifelse(BreastCancer$Class == "benign", 0, 1), ncol = 1)


## A function which will create a data object that can be used by torch (the NN library)
### In general when formatting data for torch you will need something like this
## This is modified from the original prediction problem
### ".getitem" now returns two copies of x (in as input and one as output)
BreastCancer_dataset <- dataset(
  name = "BreastCancer",
  initialize = function(x){
    self$x = torch_tensor(x, dtype = torch_float32())
  },
  
  ## boilerplate stuff
  .getitem = function(i){
    list(x = self$x[i,], y = self$x[i,])
  },
  
  ## more boilerplate stuff
  .length = function(){
    self$x$size()[[1]]
  }
)

## Creating our training/validation data (and moving them into torch-format)
ind.train <- sample(1:nrow(X), nrow(X)/2, replace = F) ## using half our data for training
train_ds <- BreastCancer_dataset(X[ind.train,])
valid_ds <- BreastCancer_dataset(X[-ind.train,])

## Creating a "dataloader" that allows torch to do calculations with the data
train_dl <- train_ds %>% dataloader(batch_size = 16, shuffle = TRUE)
valid_dl <- valid_ds %>% dataloader(batch_size = 16, shuffle = FALSE)

## creating a validation outcome (to evaluate how useful the embedding is)
y.val <- y[-ind.train]

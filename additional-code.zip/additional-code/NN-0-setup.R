## On most computers you can...
## install "torch" - the deep learning package -...
## by running the next line
install.packages("torch")

## However, if you have a newish mac (an "m1 mac")...
## Then instead you need to uncomment and run the next 3 lines
##   line numbers (10,11,12)
## it will take a few minutes for that 3rd line to run

#install.packages("remotes")
#library(remotes)
#remotes::install_github("mlverse/torch")

## Next check if you can load the "torch" library
library(torch)

## We also have a few additional support libraries
install.packages("luz") ## This is important for training NNs
install.packages("dplyr") ## This is generally useful for data manipulation
install.packages("mlbench") ## This is just used for some example data

## Testing if those packages can be loaded
library(luz)
library(mlbench)
library(dplyr)

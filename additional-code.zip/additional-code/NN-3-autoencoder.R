library(luz)
library(torch)
library(mlbench)
library(dplyr)

## Using "BreastCancer" dataset from mlbench R-library
data(BreastCancer)
names(BreastCancer)

## This will format our data into the formed needed to engage with the neural network
### in practice you will have to do this on your own...
### for now I wanted to focus on the NN piece, not the formatting

source("helpers/NN-autoencoder-helper.R")

## After running this there will be a few objects created that we will use later:
### train_ds -- the training data in torch-format
### valid_ds -- the validation data in torch-format
### train_dl -- a training dataloader 
######          that includes our training dataset, and some additional info
### valid_dl -- a validation dataloader 
######          that includes our validation dataset, and some additional info

## Here we define the neural network infrastructure/topology
### The code is a bit unusual compared to how we usually fit models in R
autoencoder <- nn_module(
  
  ## This tells us how to build all the trainable layers
  initialize = function() {
    n_dim = 2
    self$encoder <- nn_sequential(
      nn_linear(in_features = 9, out_features = 16),
      nn_relu(),
      nn_linear(in_features = 16, out_features = 32),
      nn_relu(),
      nn_linear(in_features = 32, out_features = n_dim)
    )
    self$decoder <- nn_sequential(
      nn_linear(in_features = n_dim, out_features = 16),
      nn_relu(),
      nn_linear(in_features = 16, out_features = 32),
      nn_relu(),
      nn_linear(in_features = 32,out_features = 9)
    )
  },
  
  ## This tells us how to order/connect the layers for training
  forward = function(x) {
    
    x %>% 
      self$encoder() %>%
      self$decoder()
  },
  ## This allows us to grab out the embeddings after training
  run_encoder = function(x) {
    x %>% self$encoder()
  }

)

## Here we just check to make sure we have defined our NN correctly...
### such that the dimensions of the inputs and outputs line up correctly
model_autoencoder <- autoencoder()
model_autoencoder(train_ds$x)
model_autoencoder$run_encoder(train_ds$x)

## This is the code that takes our NN, and...
#### constructs/trains it based on our training data
#### and evaluates the results based on validation data
fitted <- autoencoder %>%
  setup(
    loss = nn_mse_loss(),
    optimizer = optim_adam
  ) %>%
  set_opt_hparams(lr = 0.001) %>%
  fit(train_dl, epochs = 300, valid_data = valid_dl)

## This gives us predictions on the validation data
(preds <- predict(fitted, valid_ds))
## can also get these like
fitted$model(valid_ds$x)

## Can compare original values to embedded values
index_use <- 1 ## the index of the observation I want to compare
cbind(preds[index_use,] %>% as.numeric(),
      valid_ds[index_use]$x %>% as.numeric())


## can get the embeddings/encodings of the eg. validation data with
(encodings <- fitted$model$run_encoder(valid_ds$x))


plot(encodings[,1],encodings[,2], col = y.val+1)


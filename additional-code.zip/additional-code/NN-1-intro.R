library(luz)
library(torch)
library(mlbench)
library(dplyr)

## Using "BreastCancer" dataset from mlbench R-library
data(BreastCancer)
names(BreastCancer)

## This will format our data into the formed needed to engage with the neural network
### in practice you will have to do this on your own...
### for now I wanted to focus on the NN piece, not the formatting

source("helpers/NN-intro-helper.R")

## After running this there will be a few objects created that we will use later:
### train_ds -- the training data in torch-format
### valid_ds -- the valiation data in torch-format
### train_dl -- a training dataloader 
######          that includes our training dataset, and some additional info
### valid_dl -- a validation dataloader 
######          that includes our validation dataset, and some additional info

## Here we define the neural network infrastructure/topology
### The code is a bit unusual compared to how we usually fit models in R
net <- nn_module(
  
  ## This tells us how to build all the trainable layers
  initialize = function() {
    
    self$fc1 <- nn_linear(in_features = 9, out_features = 16)
    self$fc2 <- nn_linear(in_features = 16, out_features = 32)
    self$output <- nn_linear(in_features = 32,out_features = 1)
  },
  
  ## This tells us how to order/connect the layers
  forward = function(x) {
    
    x %>% self$fc1() %>%
      nnf_relu() %>%
      self$fc2() %>%
      nnf_relu() %>%
      self$output() %>%
      nnf_sigmoid()
  }
)

## Here we just check to make sure we have defined our NN correctly...
### such that the dimensions of the inputs and outputs line up correctly
model <- net()
batch <- dataloader_make_iter(train_dl) %>% dataloader_next() ## You generally won't have to worry about the functions here
model(batch$x)

## This is the code that takes our NN, and...
#### constructs/trains it based on our training data
#### and evaluates the results based on validation data
fitted <- net %>%
  setup(
    loss = nnf_binary_cross_entropy,
    optimizer = optim_adam
  ) %>%
  fit(train_dl, epochs = 10, valid_data = valid_dl)

## This gives us predictions on the validation data
preds <- predict(fitted, valid_ds) %>% as.numeric

## quickly peeking at misclassification rate
table(preds > 0.5, y[-ind.train])
